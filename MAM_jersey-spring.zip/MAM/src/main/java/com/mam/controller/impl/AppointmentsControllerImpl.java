package com.mam.controller.impl;

import com.mam.controller.AppointmentsController;

public class AppointmentsControllerImpl implements AppointmentsController {

	public String getAppointments() {
		return "appointments";
	}

	public String addAppointment() {
		return "add appointment";
	}

}