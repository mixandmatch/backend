package com.mam.controller.impl;

import com.mam.controller.LocationsController;

public class LocationsControllerImpl implements LocationsController {

	public String getLocations() {
		return "locations";
	}

}