package com.mam.controller.impl;

import com.mam.controller.MatchesController;

public class MatchesControllerImpl implements MatchesController {

	public String getMatches() {
		return "matches";
	}

	public String addMatch() {
		return "add match";
	}

}