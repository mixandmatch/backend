package com.mam.controller;

public interface AppointmentsController {

	String getAppointments();
	String addAppointment();

}