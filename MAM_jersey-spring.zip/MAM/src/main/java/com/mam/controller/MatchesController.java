package com.mam.controller;
 
public interface MatchesController{
 
	String getMatches();
	String addMatch();
 
}