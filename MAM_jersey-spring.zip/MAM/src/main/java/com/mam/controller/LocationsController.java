package com.mam.controller;
 
public interface LocationsController{
 
	String getLocations();
 
}