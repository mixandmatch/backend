package com.mam.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mam.controller.AppointmentsController;

@Component
@Path("/appointments")
public class AppointmentsService {

	@Autowired
	AppointmentsController appointmentsController;

	@GET
	@Path("/")
	public Response appointments() {
		String result = appointmentsController.getAppointments();
		return Response.status(200).entity(result).build();
	}

	@GET
	@Path("/add")
	public Response appointments_add() {
		String result = appointmentsController.addAppointment();
		return Response.status(200).entity(result).build();
	}

}