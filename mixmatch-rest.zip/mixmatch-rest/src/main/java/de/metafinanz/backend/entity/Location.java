package de.metafinanz.backend.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class Location implements Comparable<Location> {

	private String locationID;
	private String locationName;
	
	public Location() {
	}
	
	public Location(String locationID, String locationName) {		
		this.locationID = locationID;
		this.locationName = locationName;
	}
	
	@Override
	public int compareTo(Location o) {
		return this.locationName.compareTo(o.getLocationName());
	}

	public String getLocationID() {
		return locationID;
	}

	public void setLocationID(String locationID) {
		this.locationID = locationID;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
	
	@Override
	public String toString() {
		return getLocationName();
	}

}
