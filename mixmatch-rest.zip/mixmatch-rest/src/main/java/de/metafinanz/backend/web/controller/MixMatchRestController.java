package de.metafinanz.backend.web.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import de.metafinanz.backend.entity.Appointment;
import de.metafinanz.backend.entity.Location;

/**
 * @author ulf
 *
 */
@Controller
@RequestMapping(value = "/*")
public class MixMatchRestController {

	private List<Location> locationList = new ArrayList<Location>();
	private List<Appointment> appointmentList = new ArrayList<Appointment>();
	private Map<String, List<Appointment>> appointmentMap = new HashMap<String, List<Appointment>>();
	
	private AtomicLong idCounter = new AtomicLong(1);
	
	@PostConstruct
	public void init() {
		System.out.println("----Init");
		this.locationList.add(new Location("1", "Unterf�hring"));
		this.locationList.add(new Location("2", "M�nchen, Seidlstr."));
		this.locationList.add(new Location("3", "M�nchen, Leopoldstr."));
		this.locationList.add(new Location("4", "M�nchen, Neuperlach"));
		this.locationList.add(new Location("5", "Stuttgart"));
		Collections.sort(this.locationList);
		
		this.appointmentList.add(new Appointment("1", new Date(), "1", "ulf", null));
		this.appointmentMap.put("1", appointmentList);
	}
	
	@RequestMapping(value = "locations", method=RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Location> locations() {
		return locationList;
	}
	
	@RequestMapping(value="appointments", method=RequestMethod.GET)
	public @ResponseBody List<Appointment> appointments(@RequestParam(required=false) String locationId) {
		
		List<Appointment> result = new ArrayList<Appointment>();
		
		if (locationId != null) {
			result = this.appointmentMap.get(locationId);
		}
		
		return result;
	}
	
	
	@RequestMapping(value="appointments", method=RequestMethod.POST, consumes = "application/json")
	public @ResponseBody String createAppointment(@RequestBody Appointment appointment) {
		
		List<Appointment> appList = this.appointmentMap.get(appointment.getLocationID());
		
		appointment.setAppointmentID(String.valueOf(idCounter.incrementAndGet()));
		
		if (appList != null) {
			appList.add(appointment);
			this.appointmentMap.put(appointment.getLocationID(), appList);
		} else {
			List<Appointment> newAppList = new ArrayList<Appointment>();
			newAppList.add(appointment);
			this.appointmentMap.put(appointment.getLocationID(), newAppList);
		}		
		
		System.out.println("Create Appointment: " + appointment.toString());
		
		return appointment.getAppointmentID();
	}
	
}
